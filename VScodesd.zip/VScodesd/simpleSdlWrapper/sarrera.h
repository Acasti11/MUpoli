#ifndef SARRERA_H
#define SARRERA_H

#include "ourTypes.h"

SDL_Window *getWindow();
SDL_Rect startButtonRect; // Hasierako botoia

void menuaHasi();
void diseinuaDefinitu();
int botoiaKlikatu();
void diseinuaMarraztu();
void textuaDesgaitu();

#endif