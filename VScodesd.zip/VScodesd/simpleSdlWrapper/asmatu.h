#ifndef ASMATU_H
#define ASMATU_H

#include <stdio.h>

#define centerX (SCREEN_WIDTH / 2)
#define centerY (SCREEN_WIDTH / 2)

void jokoaAurkeztu(void);
int zaiatuAsmatzen(int zenbakiAleatorioa);
int zenbakiaAsmatu(void);

#endif