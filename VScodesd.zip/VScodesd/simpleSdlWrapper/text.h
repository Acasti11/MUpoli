#ifndef TEXT_H
#define TEXT_H

void textuaGaitu(int tamaina);
void textuaIdatzi(int x, int y, char *str, int a, int b, int c);
void textuaDesgaitu(void);

#endif
