#ifndef ERREFLEXUAK_H
#define ERREFLEXUAK_H

void jokoaAurkeztuERR(void);
void aurkezpenaERR(void);
void aurkezpena2ERR(void);
void bigarrenAzalpenaERR(void);
void bigarrenAzalpena2ERR(void);
int zenbakiakPantailaratuERR(int lehenengoJokPunt, int bigarrenJokPunt, int randomekoZenbakia);
void amaierakoPantailaERR(int irabazlea);
int erreflexuak(void);

#endif