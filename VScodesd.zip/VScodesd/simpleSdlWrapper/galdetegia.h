#ifndef GALDETEGIA_H
#define GALDETEGIA_H

#include "ourTypes.h"

void jokoaAurkeztuGAL(void);
void aurkezpenaGAL(void);
void bigarrenAzalpenaGAL(void);
int galderaPantailaratuGAL(int randomekoZenbakia); // Asegúrate de que el nombre coincida
void amaierakoPantailaGAL(int zuzena);
int ongriBuruzGaldetegia(void);

#endif
